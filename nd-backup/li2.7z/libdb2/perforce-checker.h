#pragma once
#include <string>
bool FileIsPerforceControlled(const std::string& fullyQualifiedLocalFileName);

