/*
 * Copyright (c) 2015 Naughty Dog, Inc. 
 * A Wholly Owned Subsidiary of Sony Computer Entertainment, Inc.
 * Use and distribution without consent strictly prohibited
 */

#include "gamelib/gameplay/nav/nav-defines.h"

namespace Nav
{
	const StringId64 kMatchAllBindSpawnerNameId = SID("match-all");
}
