/*
 * Copyright (c) 2009 Naughty Dog, Inc. 
 * A Wholly Owned Subsidiary of Sony Computer Entertainment, Inc.
 * Use and distribution without consent strictly prohibited
 */

#include "gamelib/gameplay/nd-attack-handler.h"

NdAttackHandler::NdAttackHandler()
{
}

NdAttackHandler::~NdAttackHandler()
{
}
