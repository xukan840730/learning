/*
* Copyright (c) 2019 Naughty Dog, Inc.
* A Wholly Owned Subsidiary of Sony Computer Entertainment, Inc.
* Use and distribution without consent strictly prohibited
*/

#include "gamelib/gameplay/animal-behavior/animal-base.h"

PROCESS_REGISTER_ABSTRACT(NdAnimalBase, NdSimpleObject);
FROM_PROCESS_DEFINE(NdAnimalBase);